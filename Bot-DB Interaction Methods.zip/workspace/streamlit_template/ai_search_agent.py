import time
from datetime import datetime
import pandas as pd
from utils import format_response, count_tokens
import json

class AISearchAgent:
    def __init__(self, db_manager):
        self.db_manager = db_manager
        self.name = "AI Search Optimized Agent"
        self.query_history = []
        self.pattern_library = self._initialize_pattern_library()
    
    def process_question(self, question: str) -> dict:
        """Process question using AI search optimized approach"""
        start_time = time.time()
        
        try:
            schema = self.db_manager.get_schema_info()
            
            # Step 1: Semantic search for similar queries
            similar_patterns = self._search_similar_patterns(question)
            
            # Step 2: Context-aware query generation
            sql_query = self._generate_context_aware_sql(question, schema, similar_patterns)
            
            # Step 3: Execute with optimization
            data = self.db_manager.execute_query(sql_query)
            
            # Step 4: Learn from this query
            self._update_pattern_library(question, sql_query, data)
            
            # Step 5: Generate insights
            insights = self._generate_ai_insights(question, data)
            
            execution_time = time.time() - start_time
            tokens_used = count_tokens(question + sql_query + str(similar_patterns))
            
            return format_response(
                sql_query=sql_query,
                data=data,
                explanation=self._generate_explanation(question, similar_patterns, insights),
                execution_time=execution_time,
                tokens_used=tokens_used,
                pattern="AI Search"
            )
            
        except Exception as e:
            return {
                'error': str(e),
                'execution_time': time.time() - start_time,
                'pattern': "AI Search"
            }
    
    def _initialize_pattern_library(self) -> dict:
        """Initialize the pattern library with common query patterns"""
        return {
            'salary_analysis': {
                'keywords': ['salary', 'pay', 'wage', 'compensation', 'average', 'mean'],
                'sql_template': """
                SELECT d.name as department, AVG(e.salary) as average_salary, 
                       COUNT(e.id) as employee_count, MAX(e.salary) as max_salary
                FROM employees e
                JOIN departments d ON e.department_id = d.id
                GROUP BY d.name
                ORDER BY average_salary DESC
                """,
                'usage_count': 0
            },
            'top_performers': {
                'keywords': ['top', 'highest', 'best', 'maximum', 'ranking'],
                'sql_template': """
                SELECT e.name, d.name as department, e.salary, 
                       COALESCE(SUM(s.amount), 0) as total_sales
                FROM employees e
                JOIN departments d ON e.department_id = d.id
                LEFT JOIN sales s ON e.id = s.employee_id
                GROUP BY e.id, e.name, d.name, e.salary
                ORDER BY e.salary DESC
                LIMIT {limit}
                """,
                'usage_count': 0
            },
            'sales_analysis': {
                'keywords': ['sales', 'revenue', 'total', 'sum', 'performance'],
                'sql_template': """
                SELECT d.name as department, SUM(s.amount) as total_sales,
                       COUNT(s.id) as sales_count, AVG(s.amount) as avg_sale_amount
                FROM sales s
                JOIN employees e ON s.employee_id = e.id
                JOIN departments d ON e.department_id = d.id
                GROUP BY d.name
                ORDER BY total_sales DESC
                """,
                'usage_count': 0
            },
            'hiring_trends': {
                'keywords': ['hired', 'new', 'recent', 'join', 'start'],
                'sql_template': """
                SELECT e.name, d.name as department, e.hire_date, e.salary,
                       julianday('now') - julianday(e.hire_date) as days_employed
                FROM employees e
                JOIN departments d ON e.department_id = d.id
                WHERE e.hire_date >= date('now', '-1 year')
                ORDER BY e.hire_date DESC
                """,
                'usage_count': 0
            },
            'correlation_analysis': {
                'keywords': ['correlation', 'relationship', 'compare', 'versus'],
                'sql_template': """
                SELECT e.name, e.salary, COALESCE(SUM(s.amount), 0) as total_sales,
                       CASE 
                           WHEN e.salary > 70000 THEN 'High Salary'
                           WHEN e.salary > 50000 THEN 'Medium Salary'
                           ELSE 'Low Salary'
                       END as salary_tier
                FROM employees e
                LEFT JOIN sales s ON e.id = s.employee_id
                GROUP BY e.id, e.name, e.salary
                HAVING total_sales > 0
                ORDER BY e.salary DESC
                """,
                'usage_count': 0
            }
        }
    
    def _search_similar_patterns(self, question: str) -> list:
        """Search for similar patterns using semantic matching"""
        question_lower = question.lower()
        question_words = set(question_lower.split())
        
        pattern_scores = []
        
        for pattern_name, pattern_data in self.pattern_library.items():
            # Calculate similarity score based on keyword matching
            pattern_keywords = set(pattern_data['keywords'])
            overlap = len(question_words.intersection(pattern_keywords))
            similarity_score = overlap / len(pattern_keywords) if pattern_keywords else 0
            
            # Boost score based on usage frequency
            usage_boost = min(pattern_data['usage_count'] * 0.1, 0.3)
            final_score = similarity_score + usage_boost
            
            if final_score > 0:
                pattern_scores.append({
                    'pattern_name': pattern_name,
                    'score': final_score,
                    'template': pattern_data['sql_template']
                })
        
        # Sort by score and return top matches
        pattern_scores.sort(key=lambda x: x['score'], reverse=True)
        return pattern_scores[:3]  # Top 3 matches
    
    def _generate_context_aware_sql(self, question: str, schema: dict, similar_patterns: list) -> str:
        """Generate SQL using context from similar patterns"""
        question_lower = question.lower()
        
        # If we have high-confidence similar patterns, adapt them
        if similar_patterns and similar_patterns[0]['score'] > 0.3:
            best_pattern = similar_patterns[0]
            sql_template = best_pattern['template']
            
            # Customize template based on specific question
            if '{limit}' in sql_template:
                # Extract number from question
                import re
                numbers = re.findall(r'\d+', question)
                limit = numbers[0] if numbers else "5"
                sql_template = sql_template.replace('{limit}', limit)
            
            return sql_template.strip()
        
        # Fallback to rule-based generation with AI enhancements
        return self._generate_enhanced_sql(question_lower, schema)
    
    def _generate_enhanced_sql(self, question: str, schema: dict) -> str:
        """Generate enhanced SQL with AI optimizations"""
        
        if "average salary" in question and "department" in question:
            return """
            SELECT d.name as department, 
                   AVG(e.salary) as average_salary,
                   COUNT(e.id) as employee_count,
                   MIN(e.salary) as min_salary,
                   MAX(e.salary) as max_salary,
                   ROUND(AVG(e.salary), 2) as avg_salary_rounded
            FROM employees e
            JOIN departments d ON e.department_id = d.id
            GROUP BY d.name
            ORDER BY average_salary DESC
            """
        
        elif "top" in question and ("highest paid" in question or "salary" in question):
            import re
            numbers = re.findall(r'\d+', question)
            limit = numbers[0] if numbers else "5"
            
            return f"""
            SELECT e.name, d.name as department, e.salary,
                   RANK() OVER (ORDER BY e.salary DESC) as salary_rank
            FROM employees e
            JOIN departments d ON e.department_id = d.id
            ORDER BY e.salary DESC
            LIMIT {limit}
            """
        
        elif "total sales" in question and "department" in question:
            return """
            SELECT d.name as department, 
                   SUM(s.amount) as total_sales,
                   COUNT(s.id) as sales_count,
                   AVG(s.amount) as avg_sale_amount,
                   COUNT(DISTINCT e.id) as active_salespeople
            FROM sales s
            JOIN employees e ON s.employee_id = e.id
            JOIN departments d ON e.department_id = d.id
            GROUP BY d.name
            ORDER BY total_sales DESC
            """
        
        elif "hired" in question or "recent" in question:
            return """
            SELECT e.name, d.name as department, e.hire_date, e.salary,
                   ROUND(julianday('now') - julianday(e.hire_date)) as days_employed
            FROM employees e
            JOIN departments d ON e.department_id = d.id
            WHERE e.hire_date >= date('now', '-1 year')
            ORDER BY e.hire_date DESC
            """
        
        else:
            return """
            SELECT e.name, d.name as department, e.salary
            FROM employees e
            JOIN departments d ON e.department_id = d.id
            ORDER BY e.salary DESC
            LIMIT 10
            """
    
    def _update_pattern_library(self, question: str, sql_query: str, data: pd.DataFrame):
        """Learn from successful queries and update pattern library"""
        question_lower = question.lower()
        
        # Update usage counts for matched patterns
        for pattern_name, pattern_data in self.pattern_library.items():
            keywords = pattern_data['keywords']
            if any(keyword in question_lower for keyword in keywords):
                self.pattern_library[pattern_name]['usage_count'] += 1
        
        # Store successful query for future reference
        self.query_history.append({
            'question': question,
            'sql_query': sql_query,
            'result_count': len(data) if data is not None else 0,
            'timestamp': datetime.now()
        })
        
        # Keep only recent history (last 50 queries)
        if len(self.query_history) > 50:
            self.query_history = self.query_history[-50:]
    
    def _generate_ai_insights(self, question: str, data: pd.DataFrame) -> dict:
        """Generate AI-powered insights from the data"""
        insights = {
            'data_quality': self._assess_data_quality(data),
            'statistical_summary': self._generate_statistical_summary(data),
            'patterns': self._identify_patterns(data),
            'recommendations': self._generate_recommendations(question, data)
        }
        
        return insights
    
    def _assess_data_quality(self, data: pd.DataFrame) -> dict:
        """Assess the quality of returned data"""
        if data is None or data.empty:
            return {'status': 'no_data', 'message': 'No data returned'}
        
        quality_score = 100
        issues = []
        
        # Check for missing values
        missing_pct = (data.isnull().sum().sum() / (len(data) * len(data.columns))) * 100
        if missing_pct > 10:
            quality_score -= 20
            issues.append(f"High missing data: {missing_pct:.1f}%")
        
        # Check for duplicate rows
        duplicate_pct = (data.duplicated().sum() / len(data)) * 100
        if duplicate_pct > 5:
            quality_score -= 15
            issues.append(f"Duplicate rows: {duplicate_pct:.1f}%")
        
        return {
            'status': 'good' if quality_score > 80 else 'fair' if quality_score > 60 else 'poor',
            'score': quality_score,
            'issues': issues
        }
    
    def _generate_statistical_summary(self, data: pd.DataFrame) -> dict:
        """Generate statistical summary of numeric columns"""
        if data is None or data.empty:
            return {}
        
        numeric_cols = data.select_dtypes(include=['number']).columns
        summary = {}
        
        for col in numeric_cols:
            summary[col] = {
                'mean': data[col].mean(),
                'median': data[col].median(),
                'std': data[col].std(),
                'min': data[col].min(),
                'max': data[col].max()
            }
        
        return summary
    
    def _identify_patterns(self, data: pd.DataFrame) -> list:
        """Identify interesting patterns in the data"""
        patterns = []
        
        if data is None or data.empty:
            return patterns
        
        # Pattern: High variance in salary
        if 'salary' in data.columns:
            salary_std = data['salary'].std()
            salary_mean = data['salary'].mean()
            if salary_std > salary_mean * 0.3:
                patterns.append("High salary variance detected - significant pay gaps exist")
        
        # Pattern: Department size imbalance
        if 'department' in data.columns:
            dept_counts = data['department'].value_counts()
            if len(dept_counts) > 1:
                ratio = dept_counts.max() / dept_counts.min()
                if ratio > 3:
                    patterns.append("Significant department size imbalance detected")
        
        # Pattern: Sales concentration
        if 'total_sales' in data.columns:
            sales_data = data['total_sales']
            top_20_pct = sales_data.quantile(0.8)
            if (sales_data >= top_20_pct).sum() / len(sales_data) < 0.3:
                patterns.append("Sales highly concentrated among top performers")
        
        return patterns
    
    def _generate_recommendations(self, question: str, data: pd.DataFrame) -> list:
        """Generate actionable recommendations based on data"""
        recommendations = []
        
        if data is None or data.empty:
            recommendations.append("Consider refining the query to return data")
            return recommendations
        
        question_lower = question.lower()
        
        if "salary" in question_lower and 'salary' in data.columns:
            salary_range = data['salary'].max() - data['salary'].min()
            if salary_range > 50000:
                recommendations.append("Consider salary standardization - large pay gaps detected")
        
        if "sales" in question_lower and 'total_sales' in data.columns:
            low_performers = (data['total_sales'] < data['total_sales'].median()).sum()
            if low_performers > len(data) * 0.6:
                recommendations.append("Focus on sales training - many employees below median performance")
        
        if len(data) < 5:
            recommendations.append("Consider expanding query scope for more comprehensive analysis")
        
        return recommendations
    
    def _generate_explanation(self, question: str, similar_patterns: list, insights: dict) -> str:
        """Generate comprehensive explanation with AI insights"""
        explanation = "AI Search Agent Analysis:\n\n"
        
        # Pattern matching info
        if similar_patterns:
            best_match = similar_patterns[0]
            explanation += f"🔍 Pattern Match: Found {best_match['score']:.2f} similarity with '{best_match['pattern_name']}' pattern\n"
        else:
            explanation += "🔍 Pattern Match: No similar patterns found, generated custom query\n"
        
        # Data quality assessment
        quality = insights.get('data_quality', {})
        explanation += f"📊 Data Quality: {quality.get('status', 'unknown').title()}"
        if quality.get('score'):
            explanation += f" (Score: {quality['score']}/100)"
        explanation += "\n"
        
        # Identified patterns
        patterns = insights.get('patterns', [])
        if patterns:
            explanation += "🔎 Key Insights:\n"
            for pattern in patterns:
                explanation += f"  • {pattern}\n"
        
        # Recommendations
        recommendations = insights.get('recommendations', [])
        if recommendations:
            explanation += "💡 Recommendations:\n"
            for rec in recommendations:
                explanation += f"  • {rec}\n"
        
        explanation += "\nThis analysis leverages machine learning patterns and historical query optimization."
        
        return explanation
import time
from datetime import datetime
import pandas as pd
from utils import format_response, count_tokens

class ReActAgent:
    def __init__(self, db_manager):
        self.db_manager = db_manager
        self.name = "ReAct Agent"
        self.max_iterations = 3
    
    def process_question(self, question: str) -> dict:
        """Process question using ReAct (Reasoning and Acting) approach"""
        start_time = time.time()
        iterations = 0
        
        try:
            schema = self.db_manager.get_schema_info()
            
            # Initial reasoning
            thought = self._initial_reasoning(question, schema)
            
            sql_query = None
            data = None
            error_history = []
            
            # Iterative refinement
            for i in range(self.max_iterations):
                iterations += 1
                
                # Generate or refine SQL
                if sql_query is None:
                    sql_query = self._generate_initial_sql(question, schema, thought)
                else:
                    sql_query = self._refine_sql(sql_query, error_history[-1], schema)
                
                # Validate and execute
                is_valid, validation_msg = self.db_manager.validate_query(sql_query)
                
                if is_valid:
                    try:
                        data = self.db_manager.execute_query(sql_query)
                        
                        # Check if results make sense
                        if self._validate_results(question, data):
                            break
                        else:
                            error_history.append("Results don't match expected pattern")
                    except Exception as e:
                        error_history.append(str(e))
                else:
                    error_history.append(validation_msg)
            
            # Generate explanation
            explanation = self._generate_explanation(question, sql_query, data, iterations, error_history)
            
            execution_time = time.time() - start_time
            tokens_used = count_tokens(thought + sql_query + str(error_history))
            
            return format_response(
                sql_query=sql_query,
                data=data if data is not None else pd.DataFrame(),
                explanation=explanation,
                execution_time=execution_time,
                tokens_used=tokens_used,
                iterations=iterations,
                pattern="ReAct"
            )
            
        except Exception as e:
            return {
                'error': str(e),
                'execution_time': time.time() - start_time,
                'iterations': iterations,
                'pattern': "ReAct"
            }
    
    def _initial_reasoning(self, question: str, schema: dict) -> str:
        """Initial reasoning about the question"""
        reasoning = f"""
        THOUGHT: I need to analyze the question "{question}" and determine what data is needed.
        
        Available tables: {list(schema.keys())}
        
        Let me break down the question:
        """
        
        question_lower = question.lower()
        
        if "average" in question_lower and "salary" in question_lower:
            reasoning += """
        - This asks for average salary calculation
        - Need to GROUP BY department if department is mentioned
        - Will use AVG() function on salary column
        - Need to JOIN employees and departments tables
        """
        
        elif "top" in question_lower or "highest" in question_lower:
            reasoning += """
        - This asks for ranking/ordering
        - Need to ORDER BY salary DESC
        - Will use LIMIT to get top N results
        - Need employee and department information
        """
        
        elif "total" in question_lower and "sales" in question_lower:
            reasoning += """
        - This asks for sum of sales data
        - Need to SUM() the amount column
        - Will GROUP BY department
        - Need to JOIN all three tables
        """
        
        return reasoning
    
    def _generate_initial_sql(self, question: str, schema: dict, thought: str) -> str:
        """Generate initial SQL based on reasoning"""
        question_lower = question.lower()
        
        # More sophisticated pattern matching with ReAct reasoning
        if "average salary" in question_lower and "department" in question_lower:
            return """
            SELECT d.name as department, AVG(e.salary) as average_salary
            FROM employees e
            JOIN departments d ON e.department_id = d.id
            GROUP BY d.name
            ORDER BY average_salary DESC
            """
        
        elif "top" in question_lower and ("highest paid" in question_lower or "salary" in question_lower):
            # Extract number if mentioned
            import re
            numbers = re.findall(r'\d+', question)
            limit = numbers[0] if numbers else "5"
            
            return f"""
            SELECT e.name, d.name as department, e.salary
            FROM employees e
            JOIN departments d ON e.department_id = d.id
            ORDER BY e.salary DESC
            LIMIT {limit}
            """
        
        elif "total sales" in question_lower and "department" in question_lower:
            return """
            SELECT d.name as department, SUM(s.amount) as total_sales, COUNT(s.id) as num_sales
            FROM sales s
            JOIN employees e ON s.employee_id = e.id
            JOIN departments d ON e.department_id = d.id
            GROUP BY d.name
            ORDER BY total_sales DESC
            """
        
        elif "hired" in question_lower:
            return """
            SELECT e.name, d.name as department, e.hire_date, e.salary
            FROM employees e
            JOIN departments d ON e.department_id = d.id
            WHERE e.hire_date >= date('now', '-1 year')
            ORDER BY e.hire_date DESC
            """
        
        else:
            return """
            SELECT e.name, d.name as department, e.salary
            FROM employees e
            JOIN departments d ON e.department_id = d.id
            ORDER BY e.salary DESC
            LIMIT 10
            """
    
    def _refine_sql(self, sql_query: str, error: str, schema: dict) -> str:
        """Refine SQL based on error feedback"""
        # Simple error correction logic
        if "no such column" in error.lower():
            # Fix column name issues
            if "avg_salary" in error:
                sql_query = sql_query.replace("avg_salary", "AVG(e.salary) as average_salary")
        
        elif "syntax error" in error.lower():
            # Fix basic syntax issues
            sql_query = sql_query.replace(";;", ";").strip()
            if not sql_query.endswith(";"):
                sql_query += ";"
        
        elif "no such table" in error.lower():
            # Fix table name issues
            sql_query = sql_query.replace("employee", "employees").replace("department", "departments")
        
        return sql_query
    
    def _validate_results(self, question: str, data: pd.DataFrame) -> bool:
        """Validate if results make sense for the question"""
        if data is None or data.empty:
            return False
        
        question_lower = question.lower()
        
        # Basic validation rules
        if "average" in question_lower and "salary" in question_lower:
            # Should have numeric salary data
            return any("salary" in col.lower() for col in data.columns)
        
        elif "top" in question_lower:
            # Should be ordered by salary (highest first)
            if "salary" in data.columns:
                return data["salary"].is_monotonic_decreasing or len(data) <= 1
        
        elif "total" in question_lower and "sales" in question_lower:
            # Should have sales amount data
            return any("sales" in col.lower() or "amount" in col.lower() for col in data.columns)
        
        return True
    
    def _generate_explanation(self, question: str, sql_query: str, data: pd.DataFrame, iterations: int, errors: list) -> str:
        """Generate detailed explanation of the ReAct process"""
        explanation = f"ReAct Agent completed the query in {iterations} iteration(s).\n\n"
        
        if errors:
            explanation += f"Encountered and resolved {len(errors)} issue(s):\n"
            for i, error in enumerate(errors, 1):
                explanation += f"{i}. {error}\n"
            explanation += "\n"
        
        if data is not None and not data.empty:
            explanation += f"Successfully retrieved {len(data)} rows of data. "
            
            # Add context-specific insights
            question_lower = question.lower()
            if "average salary" in question_lower:
                if "average_salary" in data.columns:
                    max_avg = data["average_salary"].max()
                    min_avg = data["average_salary"].min()
                    explanation += f"Salary ranges from ${min_avg:,.0f} to ${max_avg:,.0f} across departments."
            
            elif "top" in question_lower and "salary" in data.columns:
                top_salary = data["salary"].iloc[0] if len(data) > 0 else 0
                explanation += f"Highest salary found: ${top_salary:,.0f}."
            
            elif "total sales" in question_lower:
                if "total_sales" in data.columns:
                    total = data["total_sales"].sum()
                    explanation += f"Combined sales across all departments: ${total:,.0f}."
        
        else:
            explanation += "No data was retrieved. The query may need further refinement."
        
        return explanation
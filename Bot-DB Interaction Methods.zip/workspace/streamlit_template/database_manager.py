import sqlite3
import pandas as pd
import os
from datetime import datetime, timedelta
import random

class DatabaseManager:
    def __init__(self, db_path="company_database.db"):
        self.db_path = db_path
        self.setup_database()
    
    def setup_database(self):
        """Initialize database with sample data"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create tables
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS departments (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            budget REAL NOT NULL
        )
        """)
        
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            department_id INTEGER,
            salary REAL NOT NULL,
            hire_date DATE NOT NULL,
            FOREIGN KEY (department_id) REFERENCES departments (id)
        )
        """)
        
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS sales (
            id INTEGER PRIMARY KEY,
            employee_id INTEGER,
            amount REAL NOT NULL,
            sale_date DATE NOT NULL,
            FOREIGN KEY (employee_id) REFERENCES employees (id)
        )
        """)
        
        # Check if data already exists
        cursor.execute("SELECT COUNT(*) FROM departments")
        if cursor.fetchone()[0] == 0:
            self._insert_sample_data(cursor)
        
        conn.commit()
        conn.close()
    
    def _insert_sample_data(self, cursor):
        """Insert sample data into the database"""
        # Departments
        departments = [
            (1, 'Engineering', 500000),
            (2, 'Sales', 300000),
            (3, 'Marketing', 200000),
            (4, 'HR', 150000),
            (5, 'Finance', 250000)
        ]
        
        cursor.executemany(
            "INSERT INTO departments (id, name, budget) VALUES (?, ?, ?)",
            departments
        )
        
        # Employees
        first_names = ['John', 'Jane', 'Mike', 'Sarah', 'David', 'Lisa', 'Tom', 'Emma', 'Chris', 'Anna']
        last_names = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez']
        
        employees = []
        for i in range(1, 51):  # 50 employees
            name = f"{random.choice(first_names)} {random.choice(last_names)}"
            dept_id = random.randint(1, 5)
            
            # Salary based on department
            base_salaries = {1: 80000, 2: 60000, 3: 55000, 4: 50000, 5: 70000}
            salary = base_salaries[dept_id] + random.randint(-15000, 25000)
            
            # Random hire date in the last 3 years
            hire_date = datetime.now() - timedelta(days=random.randint(30, 1095))
            
            employees.append((i, name, dept_id, salary, hire_date.strftime('%Y-%m-%d')))
        
        cursor.executemany(
            "INSERT INTO employees (id, name, department_id, salary, hire_date) VALUES (?, ?, ?, ?, ?)",
            employees
        )
        
        # Sales data
        sales = []
        for i in range(1, 201):  # 200 sales records
            employee_id = random.randint(1, 50)
            amount = random.randint(1000, 50000)
            sale_date = datetime.now() - timedelta(days=random.randint(1, 365))
            
            sales.append((i, employee_id, amount, sale_date.strftime('%Y-%m-%d')))
        
        cursor.executemany(
            "INSERT INTO sales (id, employee_id, amount, sale_date) VALUES (?, ?, ?, ?)",
            sales
        )
    
    def execute_query(self, query: str) -> pd.DataFrame:
        """Execute SQL query and return results as DataFrame"""
        try:
            conn = sqlite3.connect(self.db_path)
            df = pd.read_sql_query(query, conn)
            conn.close()
            return df
        except Exception as e:
            raise Exception(f"Database query error: {str(e)}")
    
    def get_schema_info(self) -> dict:
        """Get database schema information"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        schema = {}
        
        # Get all tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cursor.fetchall()
        
        for table in tables:
            table_name = table[0]
            cursor.execute(f"PRAGMA table_info({table_name})")
            columns = cursor.fetchall()
            schema[table_name] = [f"{col[1]} ({col[2]})" for col in columns]
        
        conn.close()
        return schema
    
    def get_sample_data(self, table_name: str, limit: int = 5) -> pd.DataFrame:
        """Get sample data from a table"""
        query = f"SELECT * FROM {table_name} LIMIT {limit}"
        return self.execute_query(query)
    
    def validate_query(self, query: str) -> tuple[bool, str]:
        """Validate SQL query without executing it"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Use EXPLAIN to validate query
            cursor.execute(f"EXPLAIN {query}")
            conn.close()
            return True, "Query is valid"
        except Exception as e:
            return False, str(e)
    
    def get_table_stats(self) -> dict:
        """Get basic statistics about tables"""
        stats = {}
        
        tables = ['departments', 'employees', 'sales']
        for table in tables:
            query = f"SELECT COUNT(*) as count FROM {table}"
            result = self.execute_query(query)
            stats[table] = result['count'].iloc[0]
        
        return stats
import time
from datetime import datetime
import pandas as pd
from utils import format_response, count_tokens

class SimplePromptAgent:
    def __init__(self, db_manager):
        self.db_manager = db_manager
        self.name = "Simple Prompt Agent"
    
    def process_question(self, question: str) -> dict:
        """Process question using simple prompt approach"""
        start_time = time.time()
        
        try:
            # Get schema information
            schema = self.db_manager.get_schema_info()
            
            # Create simple prompt
            prompt = self._create_prompt(question, schema)
            
            # Generate SQL (simulated - in real implementation, use OpenAI API)
            sql_query = self._generate_sql(question, schema)
            
            # Execute query
            data = self.db_manager.execute_query(sql_query)
            
            # Generate explanation
            explanation = self._generate_explanation(question, sql_query, data)
            
            execution_time = time.time() - start_time
            tokens_used = count_tokens(prompt)
            
            return format_response(
                sql_query=sql_query,
                data=data,
                explanation=explanation,
                execution_time=execution_time,
                tokens_used=tokens_used,
                pattern="Simple Prompt"
            )
            
        except Exception as e:
            return {
                'error': str(e),
                'execution_time': time.time() - start_time,
                'pattern': "Simple Prompt"
            }
    
    def _create_prompt(self, question: str, schema: dict) -> str:
        """Create simple prompt for SQL generation"""
        schema_str = ""
        for table, columns in schema.items():
            schema_str += f"\n{table}: {', '.join(columns)}"
        
        prompt = f"""
        Given the following database schema:
        {schema_str}
        
        Generate a SQL query to answer this question: {question}
        
        Return only the SQL query without any explanation.
        """
        
        return prompt
    
    def _generate_sql(self, question: str, schema: dict) -> str:
        """Generate SQL query based on question (simplified rule-based approach)"""
        question_lower = question.lower()
        
        # Simple pattern matching for common queries
        if "average salary" in question_lower and "department" in question_lower:
            return """
            SELECT d.name as department, AVG(e.salary) as average_salary
            FROM employees e
            JOIN departments d ON e.department_id = d.id
            GROUP BY d.name
            ORDER BY average_salary DESC
            """
        
        elif "top" in question_lower and "highest paid" in question_lower:
            return """
            SELECT e.name, d.name as department, e.salary
            FROM employees e
            JOIN departments d ON e.department_id = d.id
            ORDER BY e.salary DESC
            LIMIT 5
            """
        
        elif "total sales" in question_lower and "department" in question_lower:
            return """
            SELECT d.name as department, SUM(s.amount) as total_sales
            FROM sales s
            JOIN employees e ON s.employee_id = e.id
            JOIN departments d ON e.department_id = d.id
            GROUP BY d.name
            ORDER BY total_sales DESC
            """
        
        elif "hired" in question_lower and ("last year" in question_lower or "recent" in question_lower):
            return """
            SELECT e.name, d.name as department, e.hire_date
            FROM employees e
            JOIN departments d ON e.department_id = d.id
            WHERE e.hire_date >= date('now', '-1 year')
            ORDER BY e.hire_date DESC
            """
        
        elif "correlation" in question_lower or "salary" in question_lower and "sales" in question_lower:
            return """
            SELECT e.name, e.salary, SUM(s.amount) as total_sales
            FROM employees e
            LEFT JOIN sales s ON e.id = s.employee_id
            GROUP BY e.id, e.name, e.salary
            HAVING total_sales > 0
            ORDER BY e.salary DESC
            """
        
        else:
            # Default query - show all employees
            return """
            SELECT e.name, d.name as department, e.salary
            FROM employees e
            JOIN departments d ON e.department_id = d.id
            LIMIT 10
            """
    
    def _generate_explanation(self, question: str, sql_query: str, data: pd.DataFrame) -> str:
        """Generate explanation for the query and results"""
        explanations = {
            "average salary": f"This query calculates the average salary by department. Found {len(data)} departments with salary data.",
            "top": f"This query finds the highest paid employees. Showing top {len(data)} results.",
            "total sales": f"This query calculates total sales by department. Found {len(data)} departments with sales data.",
            "hired": f"This query finds recently hired employees. Found {len(data)} employees hired in the last year.",
            "correlation": f"This query shows the relationship between salary and sales performance. Found {len(data)} employees with sales data."
        }
        
        question_lower = question.lower()
        for key, explanation in explanations.items():
            if key in question_lower:
                return explanation
        
        return f"Query executed successfully, returning {len(data)} rows of data."
# Database Chatbot Project - MVP Todo

## Overview
Create a Streamlit application that demonstrates different AI architecture patterns for querying relational databases with natural language.

## Core Files to Create (Max 8 files):

1. **app.py** - Main Streamlit application with UI and pattern selection
2. **database_manager.py** - SQLite database setup and management
3. **simple_prompt_agent.py** - Simple prompt pattern implementation
4. **react_agent.py** - ReAct-based prompt pattern
5. **multi_agent.py** - Multi-agent architecture
6. **ai_search_agent.py** - AI Search optimized agents
7. **utils.py** - Utility functions for SQL execution and formatting
8. **sample_data.sql** - Sample database schema and data

## Features to Implement:
- ✅ Database setup with sample data (employees, departments, sales)
- ✅ Four different AI architecture patterns
- ✅ Natural language to SQL conversion
- ✅ Query execution and result formatting
- ✅ Token usage tracking
- ✅ Error handling and auto-correction
- ✅ Interactive Streamlit UI with pattern comparison

## Architecture Patterns:
1. **Simple Prompt** - Direct LLM prompt for SQL generation
2. **ReAct** - Reasoning and Acting pattern with iterative refinement
3. **Multi-Agent** - Separate agents for analysis, planning, and execution
4. **AI Search** - Vector database enhanced query optimization

## Database Schema:
- employees (id, name, department_id, salary, hire_date)
- departments (id, name, budget)
- sales (id, employee_id, amount, sale_date)
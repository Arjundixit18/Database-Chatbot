import pandas as pd
from datetime import datetime
import re

def format_response(sql_query: str, data: pd.DataFrame, explanation: str, 
                   execution_time: float, tokens_used: int, pattern: str, **kwargs) -> dict:
    """Format the response from any agent in a consistent structure"""
    response = {
        'sql_query': sql_query,
        'data': data,
        'explanation': explanation,
        'execution_time': execution_time,
        'tokens_used': tokens_used,
        'pattern': pattern,
        'timestamp': datetime.now(),
        'success': True
    }
    
    # Add any additional fields
    response.update(kwargs)
    
    return response

def count_tokens(text: str) -> int:
    """Estimate token count for text (simplified approximation)"""
    if not text:
        return 0
    
    # Simple approximation: ~4 characters per token
    # This is a rough estimate for demonstration purposes
    words = len(text.split())
    chars = len(text)
    
    # Average between word-based and character-based estimates
    word_estimate = words * 1.3  # Average 1.3 tokens per word
    char_estimate = chars / 4     # Average 4 characters per token
    
    return int((word_estimate + char_estimate) / 2)

def validate_sql_syntax(sql_query: str) -> tuple[bool, str]:
    """Basic SQL syntax validation"""
    if not sql_query or not sql_query.strip():
        return False, "Empty query"
    
    sql_lower = sql_query.lower().strip()
    
    # Check for basic SQL structure
    if not sql_lower.startswith('select'):
        return False, "Query must start with SELECT"
    
    # Check for balanced parentheses
    if sql_query.count('(') != sql_query.count(')'):
        return False, "Unbalanced parentheses"
    
    # Check for dangerous operations (basic security)
    dangerous_keywords = ['drop', 'delete', 'insert', 'update', 'alter', 'create']
    for keyword in dangerous_keywords:
        if keyword in sql_lower:
            return False, f"Dangerous operation detected: {keyword.upper()}"
    
    return True, "Valid SQL syntax"

def extract_numbers_from_text(text: str) -> list:
    """Extract numbers from text using regex"""
    return [int(match) for match in re.findall(r'\d+', text)]

def clean_sql_query(sql_query: str) -> str:
    """Clean and format SQL query"""
    if not sql_query:
        return ""
    
    # Remove extra whitespace and normalize
    cleaned = ' '.join(sql_query.split())
    
    # Ensure proper semicolon ending
    if not cleaned.endswith(';'):
        cleaned += ';'
    
    return cleaned

def generate_sample_questions() -> list:
    """Generate sample questions for testing"""
    return [
        "What is the average salary by department?",
        "Who are the top 5 highest paid employees?",
        "Which department has the highest total sales?",
        "Show me employees hired in the last year",
        "What's the correlation between salary and sales performance?",
        "How many employees are in each department?",
        "What is the total budget across all departments?",
        "Which employees have no sales records?",
        "What is the average sale amount per department?",
        "Show me the salary distribution across the company"
    ]

def format_currency(amount: float) -> str:
    """Format number as currency"""
    return f"${amount:,.2f}"

def format_percentage(value: float) -> str:
    """Format number as percentage"""
    return f"{value:.1f}%"

def calculate_percentiles(data: pd.Series, percentiles: list = [25, 50, 75, 90, 95]) -> dict:
    """Calculate percentiles for a data series"""
    result = {}
    for p in percentiles:
        result[f"p{p}"] = data.quantile(p/100)
    return result

def detect_outliers(data: pd.Series, method: str = 'iqr') -> pd.Series:
    """Detect outliers in data using specified method"""
    if method == 'iqr':
        Q1 = data.quantile(0.25)
        Q3 = data.quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        return (data < lower_bound) | (data > upper_bound)
    
    elif method == 'zscore':
        z_scores = abs((data - data.mean()) / data.std())
        return z_scores > 3
    
    return pd.Series([False] * len(data), index=data.index)

def summarize_dataframe(df: pd.DataFrame) -> dict:
    """Generate comprehensive summary of a DataFrame"""
    if df is None or df.empty:
        return {'status': 'empty', 'message': 'No data to summarize'}
    
    summary = {
        'shape': df.shape,
        'columns': list(df.columns),
        'dtypes': df.dtypes.to_dict(),
        'missing_values': df.isnull().sum().to_dict(),
        'memory_usage': df.memory_usage(deep=True).sum()
    }
    
    # Numeric column statistics
    numeric_cols = df.select_dtypes(include=['number']).columns
    if len(numeric_cols) > 0:
        summary['numeric_summary'] = df[numeric_cols].describe().to_dict()
    
    # Categorical column information
    categorical_cols = df.select_dtypes(include=['object']).columns
    if len(categorical_cols) > 0:
        summary['categorical_summary'] = {}
        for col in categorical_cols:
            summary['categorical_summary'][col] = {
                'unique_count': df[col].nunique(),
                'top_values': df[col].value_counts().head().to_dict()
            }
    
    return summary

def create_visualization_suggestions(df: pd.DataFrame) -> list:
    """Suggest appropriate visualizations based on data characteristics"""
    suggestions = []
    
    if df is None or df.empty:
        return suggestions
    
    numeric_cols = df.select_dtypes(include=['number']).columns
    categorical_cols = df.select_dtypes(include=['object']).columns
    
    # Single numeric column
    if len(numeric_cols) == 1:
        suggestions.append({
            'type': 'histogram',
            'description': f'Distribution of {numeric_cols[0]}',
            'columns': [numeric_cols[0]]
        })
    
    # Two numeric columns
    if len(numeric_cols) >= 2:
        suggestions.append({
            'type': 'scatter',
            'description': f'Relationship between {numeric_cols[0]} and {numeric_cols[1]}',
            'columns': [numeric_cols[0], numeric_cols[1]]
        })
    
    # Categorical + numeric
    if len(categorical_cols) >= 1 and len(numeric_cols) >= 1:
        suggestions.append({
            'type': 'bar',
            'description': f'{numeric_cols[0]} by {categorical_cols[0]}',
            'columns': [categorical_cols[0], numeric_cols[0]]
        })
    
    # Time series (if date columns exist)
    date_cols = df.select_dtypes(include=['datetime64']).columns
    if len(date_cols) >= 1 and len(numeric_cols) >= 1:
        suggestions.append({
            'type': 'line',
            'description': f'{numeric_cols[0]} over time',
            'columns': [date_cols[0], numeric_cols[0]]
        })
    
    return suggestions

def benchmark_query_performance(query_func, iterations: int = 3) -> dict:
    """Benchmark query performance over multiple iterations"""
    import time
    
    times = []
    results = []
    
    for i in range(iterations):
        start_time = time.time()
        try:
            result = query_func()
            execution_time = time.time() - start_time
            times.append(execution_time)
            results.append(result)
        except Exception as e:
            return {
                'status': 'error',
                'error': str(e),
                'iteration': i + 1
            }
    
    return {
        'status': 'success',
        'avg_time': sum(times) / len(times),
        'min_time': min(times),
        'max_time': max(times),
        'times': times,
        'iterations': iterations
    }
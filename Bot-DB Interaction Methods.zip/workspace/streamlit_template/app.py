import streamlit as st
import sqlite3
import pandas as pd
from datetime import datetime
import plotly.express as px
import plotly.graph_objects as go
from database_manager import DatabaseManager
from simple_prompt_agent import SimplePromptAgent
from react_agent import ReActAgent
from multi_agent import MultiAgent
from ai_search_agent import AISearchAgent
import json

# Page configuration
st.set_page_config(
    page_title="Database Chatbot - AI Architecture Patterns",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        padding: 2rem;
        border-radius: 10px;
        color: white;
        text-align: center;
        margin-bottom: 2rem;
    }
    .pattern-card {
        background: #f8f9fa;
        padding: 1.5rem;
        border-radius: 10px;
        border-left: 4px solid #667eea;
        margin: 1rem 0;
    }
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1rem;
        border-radius: 8px;
        color: white;
        text-align: center;
    }
    .sql-code {
        background: #2d3748;
        color: #e2e8f0;
        padding: 1rem;
        border-radius: 8px;
        font-family: 'Courier New', monospace;
    }
</style>
""", unsafe_allow_html=True)

def initialize_session_state():
    """Initialize session state variables"""
    if 'db_manager' not in st.session_state:
        st.session_state.db_manager = DatabaseManager()
    if 'query_history' not in st.session_state:
        st.session_state.query_history = []
    if 'current_results' not in st.session_state:
        st.session_state.current_results = None

def display_header():
    """Display the main header"""
    st.markdown("""
    <div class="main-header">
        <h1>🤖 Database Chatbot</h1>
        <p>Demonstrating AI Architecture Patterns for Database Querying</p>
    </div>
    """, unsafe_allow_html=True)

def display_architecture_info():
    """Display information about different architecture patterns"""
    st.sidebar.markdown("## 🏗️ Architecture Patterns")
    
    patterns = {
        "Simple Prompt": {
            "description": "Direct LLM prompt for SQL generation",
            "pros": "Fast, simple implementation",
            "cons": "Limited error handling"
        },
        "ReAct": {
            "description": "Reasoning and Acting with iterative refinement",
            "pros": "Self-correcting, more reliable",
            "cons": "Higher token usage"
        },
        "Multi-Agent": {
            "description": "Separate agents for analysis, planning, execution",
            "pros": "Specialized expertise, scalable",
            "cons": "Complex coordination"
        },
        "AI Search": {
            "description": "Vector database enhanced optimization",
            "pros": "Context-aware, learns from history",
            "cons": "Requires vector database setup"
        }
    }
    
    for name, info in patterns.items():
        with st.sidebar.expander(f"📋 {name}"):
            st.write(f"**Description:** {info['description']}")
            st.write(f"**Pros:** {info['pros']}")
            st.write(f"**Cons:** {info['cons']}")

def display_database_schema():
    """Display database schema information"""
    st.sidebar.markdown("## 📊 Database Schema")
    
    with st.sidebar.expander("View Schema"):
        schema_info = st.session_state.db_manager.get_schema_info()
        for table, columns in schema_info.items():
            st.write(f"**{table}:**")
            for col in columns:
                st.write(f"  • {col}")

def run_query_with_pattern(question: str, pattern: str):
    """Run query using selected pattern"""
    try:
        if pattern == "Simple Prompt":
            agent = SimplePromptAgent(st.session_state.db_manager)
        elif pattern == "ReAct":
            agent = ReActAgent(st.session_state.db_manager)
        elif pattern == "Multi-Agent":
            agent = MultiAgent(st.session_state.db_manager)
        else:  # AI Search
            agent = AISearchAgent(st.session_state.db_manager)
        
        # Execute query
        result = agent.process_question(question)
        
        # Store in history
        st.session_state.query_history.append({
            'timestamp': datetime.now(),
            'question': question,
            'pattern': pattern,
            'result': result
        })
        
        return result
        
    except Exception as e:
        st.error(f"Error processing query: {str(e)}")
        return None

def display_results(result):
    """Display query results"""
    if not result:
        return
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("### 📋 Query Results")
        
        # Display SQL query
        if 'sql_query' in result:
            st.markdown("**Generated SQL:**")
            st.code(result['sql_query'], language='sql')
        
        # Display data
        if 'data' in result and not result['data'].empty:
            st.dataframe(result['data'], use_container_width=True)
            
            # Auto-generate visualizations for numeric data
            numeric_cols = result['data'].select_dtypes(include=['number']).columns
            if len(numeric_cols) > 0:
                st.markdown("### 📊 Visualization")
                
                if len(result['data']) > 1:
                    # Create appropriate chart based on data
                    if len(numeric_cols) == 1:
                        fig = px.bar(result['data'], y=numeric_cols[0])
                    else:
                        fig = px.scatter(result['data'], x=numeric_cols[0], y=numeric_cols[1])
                    
                    st.plotly_chart(fig, use_container_width=True)
        
        # Display explanation
        if 'explanation' in result:
            st.markdown("**Explanation:**")
            st.write(result['explanation'])
    
    with col2:
        st.markdown("### 📈 Metrics")
        
        # Token usage
        if 'tokens_used' in result:
            st.markdown(f"""
            <div class="metric-card">
                <h3>{result['tokens_used']}</h3>
                <p>Tokens Used</p>
            </div>
            """, unsafe_allow_html=True)
        
        # Execution time
        if 'execution_time' in result:
            st.markdown(f"""
            <div class="metric-card">
                <h3>{result['execution_time']:.2f}s</h3>
                <p>Execution Time</p>
            </div>
            """, unsafe_allow_html=True)
        
        # Iterations (for ReAct)
        if 'iterations' in result:
            st.markdown(f"""
            <div class="metric-card">
                <h3>{result['iterations']}</h3>
                <p>Iterations</p>
            </div>
            """, unsafe_allow_html=True)

def display_query_history():
    """Display query history and comparison"""
    if not st.session_state.query_history:
        return
    
    st.markdown("### 📚 Query History")
    
    # Create comparison chart
    history_df = pd.DataFrame([
        {
            'Pattern': h['pattern'],
            'Tokens': h['result'].get('tokens_used', 0) if h['result'] else 0,
            'Time': h['result'].get('execution_time', 0) if h['result'] else 0,
            'Question': h['question'][:50] + "..." if len(h['question']) > 50 else h['question']
        }
        for h in st.session_state.query_history[-10:]  # Last 10 queries
    ])
    
    if not history_df.empty:
        col1, col2 = st.columns(2)
        
        with col1:
            fig_tokens = px.bar(history_df, x='Pattern', y='Tokens', 
                              title='Token Usage by Pattern')
            st.plotly_chart(fig_tokens, use_container_width=True)
        
        with col2:
            fig_time = px.bar(history_df, x='Pattern', y='Time', 
                            title='Execution Time by Pattern')
            st.plotly_chart(fig_time, use_container_width=True)

def main():
    """Main application"""
    initialize_session_state()
    display_header()
    display_architecture_info()
    display_database_schema()
    
    # Main interface
    st.markdown("## 💬 Ask a Question")
    
    col1, col2 = st.columns([3, 1])
    
    with col1:
        question = st.text_input(
            "Enter your question about the database:",
            placeholder="e.g., What is the average salary by department?",
            key="question_input"
        )
    
    with col2:
        pattern = st.selectbox(
            "Select Pattern:",
            ["Simple Prompt", "ReAct", "Multi-Agent", "AI Search"],
            key="pattern_select"
        )
    
    # Example questions
    st.markdown("**Example questions:**")
    example_questions = [
        "What is the average salary by department?",
        "Who are the top 5 highest paid employees?",
        "Which department has the highest total sales?",
        "Show me employees hired in the last year",
        "What's the correlation between salary and sales performance?"
    ]
    
    cols = st.columns(len(example_questions))
    for i, eq in enumerate(example_questions):
        with cols[i]:
            if st.button(eq, key=f"example_{i}"):
                st.session_state.question_input = eq
                st.rerun()
    
    # Process question
    if st.button("🚀 Process Question", type="primary") and question:
        with st.spinner(f"Processing with {pattern} pattern..."):
            result = run_query_with_pattern(question, pattern)
            st.session_state.current_results = result
    
    # Display results
    if st.session_state.current_results:
        display_results(st.session_state.current_results)
    
    # Display history and comparisons
    if st.session_state.query_history:
        st.markdown("---")
        display_query_history()
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <div style="text-align: center; color: #666;">
        <p>🤖 Database Chatbot - Demonstrating AI Architecture Patterns</p>
        <p>Built with Streamlit • Powered by AI</p>
    </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()
import time
from datetime import datetime
import pandas as pd
from utils import format_response, count_tokens

class MultiAgent:
    def __init__(self, db_manager):
        self.db_manager = db_manager
        self.name = "Multi-Agent System"
        self.analyzer = QueryAnalyzer()
        self.planner = QueryPlanner()
        self.executor = QueryExecutor(db_manager)
        self.validator = ResultValidator()
    
    def process_question(self, question: str) -> dict:
        """Process question using multi-agent approach"""
        start_time = time.time()
        
        try:
            schema = self.db_manager.get_schema_info()
            
            # Step 1: Analysis Agent
            analysis = self.analyzer.analyze_question(question, schema)
            
            # Step 2: Planning Agent
            plan = self.planner.create_query_plan(analysis)
            
            # Step 3: Execution Agent
            execution_result = self.executor.execute_plan(plan)
            
            # Step 4: Validation Agent
            validation = self.validator.validate_results(question, execution_result)
            
            # If validation fails, retry with refined plan
            if not validation['is_valid'] and validation['suggestions']:
                refined_plan = self.planner.refine_plan(plan, validation['suggestions'])
                execution_result = self.executor.execute_plan(refined_plan)
            
            execution_time = time.time() - start_time
            
            # Calculate total tokens used across all agents
            total_tokens = (
                count_tokens(str(analysis)) +
                count_tokens(str(plan)) +
                count_tokens(str(execution_result)) +
                count_tokens(str(validation))
            )
            
            return format_response(
                sql_query=execution_result.get('sql_query', ''),
                data=execution_result.get('data', pd.DataFrame()),
                explanation=self._generate_explanation(analysis, plan, execution_result, validation),
                execution_time=execution_time,
                tokens_used=total_tokens,
                pattern="Multi-Agent"
            )
            
        except Exception as e:
            return {
                'error': str(e),
                'execution_time': time.time() - start_time,
                'pattern': "Multi-Agent"
            }
    
    def _generate_explanation(self, analysis: dict, plan: dict, execution: dict, validation: dict) -> str:
        """Generate comprehensive explanation from all agents"""
        explanation = "Multi-Agent System Analysis:\n\n"
        
        explanation += f"🔍 Analysis Agent: {analysis.get('summary', 'Analyzed the question structure')}\n"
        explanation += f"📋 Planning Agent: {plan.get('strategy', 'Created execution strategy')}\n"
        explanation += f"⚡ Execution Agent: {execution.get('status', 'Executed the query')}\n"
        explanation += f"✅ Validation Agent: {validation.get('message', 'Validated results')}\n\n"
        
        if execution.get('data') is not None and not execution['data'].empty:
            data = execution['data']
            explanation += f"Retrieved {len(data)} rows across {len(data.columns)} columns. "
            explanation += "Each agent contributed specialized expertise to ensure accurate results."
        
        return explanation

class QueryAnalyzer:
    """Agent responsible for analyzing and understanding the question"""
    
    def analyze_question(self, question: str, schema: dict) -> dict:
        """Analyze the question to understand intent and requirements"""
        question_lower = question.lower()
        
        analysis = {
            'intent': self._identify_intent(question_lower),
            'entities': self._extract_entities(question_lower, schema),
            'aggregations': self._identify_aggregations(question_lower),
            'filters': self._identify_filters(question_lower),
            'summary': ''
        }
        
        # Generate summary
        analysis['summary'] = f"Identified {analysis['intent']} query requiring {', '.join(analysis['entities'])} data"
        if analysis['aggregations']:
            analysis['summary'] += f" with {', '.join(analysis['aggregations'])} operations"
        
        return analysis
    
    def _identify_intent(self, question: str) -> str:
        """Identify the main intent of the question"""
        if any(word in question for word in ['average', 'mean']):
            return 'aggregation'
        elif any(word in question for word in ['top', 'highest', 'best', 'maximum']):
            return 'ranking'
        elif any(word in question for word in ['total', 'sum', 'count']):
            return 'aggregation'
        elif any(word in question for word in ['list', 'show', 'find', 'get']):
            return 'retrieval'
        elif any(word in question for word in ['correlation', 'relationship', 'compare']):
            return 'analysis'
        else:
            return 'general_query'
    
    def _extract_entities(self, question: str, schema: dict) -> list:
        """Extract relevant database entities from the question"""
        entities = []
        
        if 'employee' in question or 'staff' in question or 'worker' in question:
            entities.append('employees')
        if 'department' in question or 'dept' in question:
            entities.append('departments')
        if 'sales' in question or 'revenue' in question:
            entities.append('sales')
        if 'salary' in question or 'pay' in question or 'wage' in question:
            entities.append('salary')
        
        return entities
    
    def _identify_aggregations(self, question: str) -> list:
        """Identify required aggregation operations"""
        aggregations = []
        
        if any(word in question for word in ['average', 'mean']):
            aggregations.append('AVG')
        if any(word in question for word in ['total', 'sum']):
            aggregations.append('SUM')
        if any(word in question for word in ['count', 'number']):
            aggregations.append('COUNT')
        if any(word in question for word in ['maximum', 'max', 'highest']):
            aggregations.append('MAX')
        if any(word in question for word in ['minimum', 'min', 'lowest']):
            aggregations.append('MIN')
        
        return aggregations
    
    def _identify_filters(self, question: str) -> list:
        """Identify filtering requirements"""
        filters = []
        
        if 'last year' in question or 'recent' in question:
            filters.append('date_filter')
        if any(word in question for word in ['top', 'limit', 'first']):
            filters.append('limit')
        if 'department' in question and any(word in question for word in ['specific', 'particular']):
            filters.append('department_filter')
        
        return filters

class QueryPlanner:
    """Agent responsible for creating execution plans"""
    
    def create_query_plan(self, analysis: dict) -> dict:
        """Create a detailed execution plan based on analysis"""
        plan = {
            'tables': self._determine_tables(analysis),
            'joins': self._determine_joins(analysis),
            'columns': self._determine_columns(analysis),
            'where_clauses': self._determine_filters(analysis),
            'group_by': self._determine_grouping(analysis),
            'order_by': self._determine_ordering(analysis),
            'limit': self._determine_limit(analysis),
            'strategy': ''
        }
        
        plan['strategy'] = f"Query {', '.join(plan['tables'])} with {len(plan['joins'])} joins"
        
        return plan
    
    def _determine_tables(self, analysis: dict) -> list:
        """Determine which tables are needed"""
        tables = []
        entities = analysis['entities']
        
        if 'employees' in entities or 'salary' in entities:
            tables.append('employees')
        if 'departments' in entities:
            tables.append('departments')
        if 'sales' in entities:
            tables.append('sales')
        
        # Default to employees if no specific entities
        if not tables:
            tables.append('employees')
        
        return tables
    
    def _determine_joins(self, analysis: dict) -> list:
        """Determine necessary joins"""
        joins = []
        tables = self._determine_tables(analysis)
        
        if 'employees' in tables and 'departments' in tables:
            joins.append('employees.department_id = departments.id')
        if 'sales' in tables and 'employees' in tables:
            joins.append('sales.employee_id = employees.id')
        
        return joins
    
    def _determine_columns(self, analysis: dict) -> list:
        """Determine which columns to select"""
        columns = []
        
        if analysis['intent'] == 'aggregation':
            if 'AVG' in analysis['aggregations']:
                columns.append('AVG(e.salary) as average_salary')
            if 'SUM' in analysis['aggregations']:
                columns.append('SUM(s.amount) as total_sales')
            if 'COUNT' in analysis['aggregations']:
                columns.append('COUNT(*) as count')
        else:
            columns.extend(['e.name', 'd.name as department', 'e.salary'])
        
        return columns
    
    def _determine_filters(self, analysis: dict) -> list:
        """Determine WHERE clauses"""
        filters = []
        
        if 'date_filter' in analysis['filters']:
            filters.append("e.hire_date >= date('now', '-1 year')")
        
        return filters
    
    def _determine_grouping(self, analysis: dict) -> list:
        """Determine GROUP BY clauses"""
        if analysis['intent'] == 'aggregation' and 'departments' in analysis['entities']:
            return ['d.name']
        return []
    
    def _determine_ordering(self, analysis: dict) -> list:
        """Determine ORDER BY clauses"""
        if analysis['intent'] == 'ranking':
            return ['e.salary DESC']
        elif analysis['intent'] == 'aggregation':
            return ['average_salary DESC'] if 'AVG' in analysis['aggregations'] else ['total_sales DESC']
        return []
    
    def _determine_limit(self, analysis: dict) -> int:
        """Determine LIMIT clause"""
        if analysis['intent'] == 'ranking':
            return 5
        return None
    
    def refine_plan(self, original_plan: dict, suggestions: list) -> dict:
        """Refine the plan based on validation suggestions"""
        refined_plan = original_plan.copy()
        
        for suggestion in suggestions:
            if 'add_department_join' in suggestion:
                if 'employees.department_id = departments.id' not in refined_plan['joins']:
                    refined_plan['joins'].append('employees.department_id = departments.id')
                    refined_plan['tables'].append('departments')
        
        return refined_plan

class QueryExecutor:
    """Agent responsible for executing queries"""
    
    def __init__(self, db_manager):
        self.db_manager = db_manager
    
    def execute_plan(self, plan: dict) -> dict:
        """Execute the query plan"""
        try:
            sql_query = self._build_sql_from_plan(plan)
            data = self.db_manager.execute_query(sql_query)
            
            return {
                'sql_query': sql_query,
                'data': data,
                'status': f'Successfully executed query returning {len(data)} rows'
            }
            
        except Exception as e:
            return {
                'sql_query': '',
                'data': pd.DataFrame(),
                'status': f'Execution failed: {str(e)}',
                'error': str(e)
            }
    
    def _build_sql_from_plan(self, plan: dict) -> str:
        """Build SQL query from the execution plan"""
        # SELECT clause
        select_clause = "SELECT " + ", ".join(plan['columns'])
        
        # FROM clause
        main_table = plan['tables'][0]
        from_clause = f"FROM {main_table} e"
        
        # JOIN clauses
        join_clauses = ""
        if 'departments' in plan['tables']:
            join_clauses += " JOIN departments d ON e.department_id = d.id"
        if 'sales' in plan['tables']:
            join_clauses += " JOIN sales s ON s.employee_id = e.id"
        
        # WHERE clause
        where_clause = ""
        if plan['where_clauses']:
            where_clause = " WHERE " + " AND ".join(plan['where_clauses'])
        
        # GROUP BY clause
        group_clause = ""
        if plan['group_by']:
            group_clause = " GROUP BY " + ", ".join(plan['group_by'])
        
        # ORDER BY clause
        order_clause = ""
        if plan['order_by']:
            order_clause = " ORDER BY " + ", ".join(plan['order_by'])
        
        # LIMIT clause
        limit_clause = ""
        if plan['limit']:
            limit_clause = f" LIMIT {plan['limit']}"
        
        # Combine all parts
        sql_query = select_clause + from_clause + join_clauses + where_clause + group_clause + order_clause + limit_clause
        
        return sql_query

class ResultValidator:
    """Agent responsible for validating query results"""
    
    def validate_results(self, question: str, execution_result: dict) -> dict:
        """Validate the execution results"""
        data = execution_result.get('data')
        
        if data is None or data.empty:
            return {
                'is_valid': False,
                'message': 'No data returned',
                'suggestions': ['check_query_logic', 'verify_table_relationships']
            }
        
        question_lower = question.lower()
        suggestions = []
        
        # Validate based on question type
        if 'department' in question_lower and 'department' not in str(data.columns).lower():
            suggestions.append('add_department_join')
        
        if 'salary' in question_lower and 'salary' not in str(data.columns).lower():
            suggestions.append('include_salary_column')
        
        is_valid = len(suggestions) == 0
        
        return {
            'is_valid': is_valid,
            'message': 'Results validated successfully' if is_valid else 'Results need refinement',
            'suggestions': suggestions
        }